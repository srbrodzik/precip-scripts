dewp_to_qv <-
function(p,td){
## function converts dewpoint (C) to mixing ratio (in kg/kg). Inputs are p (Pa) and Td (C)
 eps=287.04/461.5
 es = 611.2*exp(17.67*(td-273.15)/(td-29.65))
 val = eps*es/(p-es)
return(val) }
