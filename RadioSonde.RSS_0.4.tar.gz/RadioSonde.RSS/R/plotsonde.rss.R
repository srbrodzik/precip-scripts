plotsonde.rss <-
function (dataframe, skewT = TRUE, winds = FALSE, site = "", 
    title = "", windplot = NULL, s = 3, col = c(1, 2), ...) 
{
    msg <- deparse(match.call())
    if (skewT & winds) {
        mar.skewt <- c(4.1, 2.7, 2.1, 3.5)
        skewt.plt <- skewt.axis.rss(mar = mar.skewt)$plt
        title(title)
        if (is.null(windplot)) {
            windplot <- skewt.plt
            windplot[1] <- 0.8
            windplot[2] <- 0.95
        }
        else if ((windplot[2] < windplot[1]) | (windplot[4] < 
            windplot[3])) {
            stop("plot region (windplot) too small to add second plot")
        }
        first.par <- par()
        skewt.axis.rss()
        skewt.lines(dataframe$temp, dataframe$press, col = col[1], 
            ...)
        skewt.lines(dataframe$dewpt, dataframe$press, col = col[2], 
            ...)
        print(windplot)
        par(new = TRUE, pty = "m", plt = windplot, err = -1)
        plotwind.rss(dataframe = dataframe, size = s, legend = FALSE)
        par(plt = first.par$plt, mar = first.par$mar, new = FALSE, 
            pty = first.par$pty, usr = first.par$usr)
        invisible()
    }
    else if (skewT & !winds) {
        skewt.axis()
        skewt.lines(dataframe$temp, dataframe$press, col = col[1], 
            ...)
        skewt.lines(dataframe$dewpt, dataframe$press, col = col[2], 
            ...)
        title(title)
    }
    else if (!skewT & winds) {
        plotwind(dataframe = dataframe, ...)
        title(title)
    }
    invisible()
}
