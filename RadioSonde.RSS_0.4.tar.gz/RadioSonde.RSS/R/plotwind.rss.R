plotwind.rss <-
function (dataframe, size = 5, ylim = c(1050, 100), legend = FALSE) 
{
    y <- dataframe$press
    y <- y[!is.na(y)]
    y <- skewty(y)
    ylim <- skewty(ylim)
    n <- length(y)
    u <- dataframe$uwind
    v <- dataframe$vwind
    theta <- as.integer(dataframe$dir)
    speed <- dataframe$wspd
    speed <- round(speed, digits = 0)
    speed <- as.integer(speed)
    plot(c(-1.5, 1.5), ylim, axes = FALSE, type = "n", xlab = "", 
        ylab = "")
    if (legend) {
        mtext("full barb = 10 m/s", side = 1, line = 1)
    }
    abline(v = -0.5)
    for (k in 1:length(y)) {
        if (y[k] > ylim[2]) 
            break
        if (!is.na(speed[k])) {
            if (speed[k] != 999) {
                station.symbol.rss(-0.5, y[k], speed = speed[k], direction = theta[k], 
                  circle = FALSE, cex = size)
            }
        }
    }
}
