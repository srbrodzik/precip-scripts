skewt.axis.rss <-
function (BROWN = "brown", GREEN = "green", ...) 
{
## RSS: 5/2013: This version uses a calculation of "theta_e_v", which is the 
##   temp_v that a parcel would have if lifted saturated from the surface
## this is a non-conserved quantity but parallels the parcel curves calculated using the T_v correction 
    data("skewt.data.rss")
    tmr <- function(w, p) {
        c1 <- 0.0498646455
        c2 <- 2.4082965
        c3 <- 7.07475
        c4 <- 38.9114
        c5 <- 0.0915
        c6 <- 1.2035
        x <- log10((w * p)/(622 + w))
        tmrk <- 10^(c1 * x + c2) - c3 + c4 * ((10^(c5 * x) - 
            c6)^2)
        tmrk - 273.15
    }
    tda <- function(o, p) {
        ok <- o + 273.15
        tdak <- ok * ((p * 0.001)^0.286)
        tdak - 273.15
    }
    par(pty = "s", ...)
    ymax <- skewty(1050)
    ymin <- skewty(100)
    xmin <- skewtx(-33, skewty(1050))
    xmax <- skewtx(50, skewty(1000))
    kinkx <- skewtx(5, skewty(400))
    xc <- c(xmin, xmin, xmax, xmax, kinkx, kinkx, xmin)
    yc <- c(ymin, ymax, ymax, skewty(625), skewty(400), ymin, 
        ymin)
    plot(xc, yc, type = "l", axes = FALSE, xlab = "", ylab = "", 
        lwd = 0.3)
    ypos <- skewty(1050)
## RSS this is really deg F
#    degc <- ((seq(-20, 100, by = 20) - 32) * 5)/9
    degc <- seq(-30,40, by = 10)
#    axis(1, at = skewtx(degc, ypos), labels = seq(-20, 100, by = 20), 
#        pos = ymax)
#    mtext(side = 1, line = 1, "Temperature (F)")
# RSS changing to C
    axis(1, at = skewtx(degc, ypos), labels = seq(-30, 40, by = 10), 
        pos = ymax, cex.axis=1.1)
    mtext(side = 1, line = 1, "Temperature (C)", cex=1.1)
    pres <- c(1050, 1000, 850, 700, 500, 400, 300, 250, 200, 
        150, 100)
    NPRES <- length(pres)
    xpl <- rep(xmin, times = NPRES)
    xpr <- c(xmax, xmax, xmax, xmax, skewtx(20, skewty(500)), 
        kinkx, kinkx, kinkx, kinkx, kinkx, kinkx)
    y <- skewty(pres)
# pressure
    segments(xpl, y, xpr, y, col = BROWN, lwd = 0.4, lty = 1)
    ypos <- skewty(pres[2:NPRES])
    axis(2, at = ypos, labels = pres[2:NPRES], pos = xmin,cex.axis=1.2)
    mtext(side = 2, line = 1.5, "P (hPa)")
    temp <- seq(from = -100, to = 50, by = 10)
    NTEMP <- length(temp)
    lendt <- rep(1050, NTEMP)
    inds <- seq(1, length(temp))[temp < -30]
    exponent <- (132.182 - (xmin - 0.54 * temp[inds])/0.90692)/44.061
    lendt[inds] <- 10^exponent
    rendt <- rep(100, NTEMP)
    inds <- seq(1, length(temp))[(temp >= -30) & (temp <= 0)]
    exponent <- (132.182 - (kinkx - 0.54 * temp[inds])/0.90692)/44.061
    rendt[inds] <- 10^exponent
    inds <- seq(1, length(temp))[temp > 30]
    exponent <- (132.182 - (xmax - 0.54 * temp[inds])/0.90692)/44.061
    rendt[inds] <- 10^exponent
    rendt[temp == 10] <- 430
    rendt[temp == 20] <- 500
    rendt[temp == 30] <- 580
    yr <- skewty(rendt)
    xr <- skewtx(temp, yr)
    yl <- skewty(lendt)
    xl <- skewtx(temp, yl)
# temperature
    segments(xl, yl, xr, yr, col = BROWN, lwd = 0.3)
    text(xr[8:NTEMP], yr[8:NTEMP], labels = paste(" ", as.character(temp[8:NTEMP])), 
        srt = 45, adj = 0, col = BROWN)
    mixrat <- c(20, 12, 8, 5, 3, 2, 1)
    NMIX <- length(mixrat)
    yr <- skewty(440)
    tmix <- tmr(mixrat[1], 440)
    xr <- skewtx(tmix, yr)
    yl <- skewty(1000)
    tmix <- tmr(mixrat[1], 1000)
    xl <- skewtx(tmix, yl)
# mixing ratio
    segments(xl, yl, xr, yr, lty = 2, col = GREEN, lwd = 0.8)
    yl <- skewty(1025)
    xl <- skewtx(tmix, yl)
    text(xl, yl, labels = as.character(mixrat[1]), col = GREEN, 
        srt = 55, adj = 0.5, cex = 1.0)
    yr <- skewty(rep(400, NMIX - 1))
    tmix <- tmr(mixrat[2:NMIX], 400)
    xr <- skewtx(tmix, yr)
    yl <- skewty(rep(1000, NMIX - 1))
    tmix <- tmr(mixrat[2:NMIX], 1000)
    xl <- skewtx(tmix, yl)
# also mixing ratio
    segments(xl, yl, xr, yr, lty = 2, col = GREEN, lwd = 0.8)
    yl <- skewty(rep(1025, NMIX - 1))
    xl <- skewtx(tmix, yl)
    text(xl, yl, labels = as.character(mixrat[2:NMIX]), col = GREEN, 
        srt = 55, adj = 0.5, cex = 1.0)
    theta <- seq(from = -30, to = 170, by = 10)
    NTHETA <- length(theta)
    lendth <- rep(100, times = NTHETA)
    lendth[1:8] <- c(880, 670, 512, 388, 292, 220, 163, 119)
    rendth <- rep(1050, times = NTHETA)
    rendth[9:NTHETA] <- c(1003, 852, 728, 618, 395, 334, 286, 
        245, 210, 180, 155, 133, 115)
# theta
    for (itheta in 1:NTHETA) {
        p <- seq(from = lendth[itheta], to = rendth[itheta], 
            length = 200)
        sy <- skewty(p)
        dry <- tda(theta[itheta], p)
        sx <- skewtx(dry, sy)
        lines(sx, sy, lty = 1, col = BROWN,lwd=1.2)
    }
    p <- seq(from = 1000, to = 240, by = -10)
    npts <- length(p)
    sy <- skewty(p)
    sx <- double(length = npts)
## bringing in the pseudo adiabats we calculated from GHB's code
        holdx <- skewt.data.rss$pseudox
        holdy <- skewt.data.rss$pseudoy
        pseudo <- skewt.data.rss$pseudo
        NPSEUDO <- skewt.data.rss$NPSEUDO
    for (ipseudo in 1:NPSEUDO) {
        sx <- holdx[, ipseudo]
        sy <- holdy[, ipseudo]
# pseudo adiabats
        lines(sx, sy, lty = 1, lwd=1.2, col = GREEN)
        moist <- satlft(pseudo[ipseudo], 230)
        labely <- skewty(230)
        labelx <- skewtx(moist, labely)
        if (labelx > xmin) 
    #        text(labelx, labely, labels = as.character(pseudo[ipseudo]), 
    #            col = GREEN, adj = 0.5, cex = 1.0)
        moist <- satlft(pseudo[ipseudo], 1100)
        labely <- skewty(1100)
        labelx <- skewtx(moist, labely)
    #    text(labelx, labely, labels = as.character(pseudo[ipseudo]), 
    #        col = GREEN, adj = 0.5, cex = 1.0)
    }
    invisible(list(pseudox = holdx, pseudoy = holdy, pseudo = pseudo, 
        NPSEUDO = NPSEUDO, plt = par()$plt))
}
