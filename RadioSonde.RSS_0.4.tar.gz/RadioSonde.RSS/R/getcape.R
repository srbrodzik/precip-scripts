getcape <-
function(source,data){
### function to do the Bryan getcape calculation
## inputs are a value of source (1=surface based, 2=MU, 3=ML) and
###    a data frame with columns called "press" (hPa), "temp" (C), and "qv" (kg/kg)
## outputs a data frame with cape, cin, and other parameters
#dyn.load("~rschumac/R/getcape.so")
#source("~rschumac/R/qv_to_dewp.R")
cape <- 0.0
cin <- 0.0
plcl <- 0.0
plfc <- 0.0
pel <- 0.0
psource <- 0.0
tsource <- 0.0
qvsource <- 0.0
ptv <- matrix(0,nrow=length(data$press))
ppres <- matrix(0,nrow=length(data$press))

out <- .Fortran("getcape", source=as.integer(source), nk=as.integer(length(data$press)), p_in=as.double(data$press), t_in=as.double(data$temp), q_in=as.double(data$qv), cape , cin, 
                        plcl, plfc, pel , psource , tsource , qvsource, ptv, ppres, PACKAGE="RadioSonde.RSS" )

cape <- out[[6]]
cin <- out[[7]]
plcl <- out[[8]]
plfc <- out[[9]]
pel <- out[[10]]
psource <- out[[11]]
tsource <- out[[12]]-273.15
qvsource <- out[[13]] 
tdsource <- qv_to_dewp(psource/100.,qvsource)-273.15
ptv <- out[[14]]
ppres <- out[[15]]
capeout <- data.frame(cape,cin,plcl,plfc,pel,psource,tsource,tdsource,qvsource,ptv,ppres)
return(capeout)
}
