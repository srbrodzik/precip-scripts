qv_to_dewp <- function(p,q){
## function converts mixing ratio (in kg/kg) to dewpoint (C).  Inputs are p (hPa) and q (kg/kg)
el = log((q/0.622)*(p)/(1.0+(q/0.622)))
tdc = 273.15+(243.5*el-440.8)/(19.48-el)
return(tdc) }
