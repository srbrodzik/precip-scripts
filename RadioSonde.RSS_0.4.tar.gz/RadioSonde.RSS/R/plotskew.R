plotskew <-
function(data, hodo=NULL, parcel=NULL, thinwind=1, title="",date="") {
## R function to plot a skew-T diagram, with the Bryan getcape code wrapped in.  Awesome!
##  inputs are two data frames:
##  1) data:  in the form required by the "RadioSonde" package, including
##  pressure, temperature, etc., 
##  2) hodo (optional): having height and wind speed/direction
## parcel is a specification of which parcel to plot, 
##  where 1=SB, 2=MU, and 3=ML
## thinwind will thin out the wind barb plotting.  1=plot all levels, 5=plot
##  every 5th level, etc.
## title is the main title for the plot; date is date/time information like the initialization time, etc.
##   the one thing it won't correctly plot is the title and date/time information,
##  which should be added later by the main program
##  RSS 5/2/2013

## load in needed libraries/scripts
#library("RadioSonde")
#library("plotrix")
#source("thermo.R")

## convert to speed/direction if needed
if(is.null(data$wspd) && is.null(data$dir)){
  wspd <- sqrt(data$uwind^2 + data$vwind^2) 
  data <- cbind(data, wspd)

  dir <- 90.-atan2(-data$vwind, -data$uwind)*(180./pi)
  data <- cbind(data,dir)
}

## calculate q if we don't have it
if(is.null(data$qv)) {
 qv <- dewp_to_qv(data$press*100.,data$dewpt+273.15)
 data <- cbind(data, qv)
}

## and the virtual temperature of the sounding
tempv <- (data$temp+273.15)*(1.0+(461.5/287.04)*data$qv)/(1.0+data$qv)-273.15
data <- cbind(data,tempv)


## now, split up the thermodynamic and wind portions into their own data frames
data_thermo <- data[,c("press","temp","dewpt","qv","tempv")]
data_winds <- data[,c("press","wspd","dir")]
data_winds <- data_winds[complete.cases(data_winds),]
data_winds <- data_winds[seq(1,length(data_winds$press),by=thinwind),]

  plotsonde.csu(data_thermo,data_winds, lwd=c(4,4,2), winds=T, col=c(2,3,1,1,1), s=1.8)
  title(title,cex.main=1.2)
  mtext(date,cex=1.1,padj=1)
  skewt.lines(data$tempv,data$press, col="red", lwd=1.1,lty=2)  ## add the virtual temp of the sounding
 
## now run the wrapper for getcape to calculate CAPE!

data <- data[complete.cases(data$press),] # now cut down to just the complete pressure lines 
data <- data[complete.cases(data$temp),] # now cut down to just the complete temp lines
data$qv[is.na(data$qv)]<-0  ## set qv to zero where it's missing to avoid problems in getcape

## do pw calc first
  pw <- PWV(data, minp=100)

## SBCAPE
sbcape <- getcape(1,data)
## MUCAPE
mucape <- getcape(2,data)
## MLCAPE
mlcape <- getcape(3,data)
## strip out the parcel temperature from this array
sbptv <- sbcape$ptv - 273.15
sbppres <- sbcape$ppres
sbcape <- sbcape[1,]
muptv <- mucape$ptv - 273.15
muppres <- mucape$ppres
mucape <- mucape[1,]
mlptv <- mlcape$ptv - 273.15
mlppres <- mlcape$ppres
mlcape <- mlcape[1,]

## and get and plot the parcel path for the desired parcel, if there is CAPE and the EL is defined
##  do the initial lifting of the dry parcel first
if (!parcel) { print("no parcel being drawn")   
} else if (parcel == 1){   ## SBCAPE
 print(sbcape)
# if (sbcape$cape > 0 && sbcape$pel != 0){
  if (sbcape$cape > 0){
  mtext("dashed black line shows ascent of surface parcel",side=1,padj=1,adj=-0.05, cex=0.8)
  skewt.lines(sbptv[sbppres<=sbcape$psource & sbppres>=sbcape$pel],
    sbppres[sbppres<=sbcape$psource & sbppres>=sbcape$pel]/100.,col="black",lwd=2.5,lty=2) 
 }
} else if (parcel == 2){  ## MUCAPE 
 print(mucape)
# if (mucape$cape > 0 && mucape$pel != 0){
  if (mucape$cape > 0){
  mtext("dashed black line shows ascent of parcel with max theta-e",side=1,padj=1,adj=-0.05, cex=0.8)
#  skewt.lines(muptv[muppres<=mucape$psource & muppres>=mucape$pel],
#    muppres[muppres<=mucape$psource & muppres>=mucape$pel]/100.,col="black",lwd=2.5,lty=2) 
  skewt.lines(muptv[muppres<=mucape$psource],
    muppres[muppres<=mucape$psource]/100.,col="black",lwd=2.5,lty=2) 
 }
} else if (parcel == 3){  ## MLCAPE 
 print(mlcape)
# if (mlcape$cape > 0 && mlcape$pel != 0){
  if (mlcape$cape > 0){
  mtext("dashed black line shows mean 500-m layer parcel",side=1,padj=1,adj=-0.05, cex=0.8)
#  skewt.lines(mlptv[mlppres<=mlcape$psource & mlppres>=mlcape$pel],
#   mlppres[mlppres<=mlcape$psource & mlppres>=mlcape$pel]/100.,col="black",lwd=2.5,lty=2) 
  skewt.lines(mlptv[mlppres<=mlcape$psource],
   mlppres[mlppres<=mlcape$psource]/100.,col="black",lwd=2.5,lty=2) 
 }
} 

## and get hodograph if desired
if(!is.null(hodo)) {
 if(!is.null(hodo$wspd) && !is.null(hodo$dir)){ ## if the direction is supplied in the data, then 
    hodo$dir <- -(hodo$dir+90.-180.)+180.  ## make this silly correction to account for direction plotting in R
 }
 if(is.null(hodo$wspd) && is.null(hodo$dir)){
    wspd <- sqrt(hodo$uwind^2 + hodo$vwind^2) 
    hodo <- cbind(hodo, wspd)

    dir <- 180.+atan2(-hodo$vwind, -hodo$uwind)*(180./pi)
    hodo <- cbind(hodo,dir)
  }

## calculate shear quantities
## calculate shear quantities
    shear06u <- hodo$uwind[hodo$height==6000]-hodo$uwind[hodo$height==10]
    shear06v <- hodo$vwind[hodo$height==6000]-hodo$vwind[hodo$height==10]
    shear01u <- hodo$uwind[hodo$height==1000]-hodo$uwind[hodo$height==10]
    shear01v <- hodo$vwind[hodo$height==1000]-hodo$vwind[hodo$height==10]
    shear06 <- round(sqrt(shear06u^2+shear06v^2),digits=1)
    shear01 <- round(sqrt(shear01u^2+shear01v^2),digits=1)
}

## make non-existent LFCs NA
    if(sbcape$plfc == 0 ) { sbcape$plfc <- NA }
    if(mucape$plfc == 0 ) { mucape$plfc <- NA }
    if(mlcape$plfc == 0 ) { mlcape$plfc <- NA }

## before plotting hodograph, add legend with the stability and shear info:
## add legend box
if(is.null(hodo)){  ## omit shear variables if no hodo
              legend("topright", inset=c(.15,0.0375), cex=0.75, lty=NULL, bg="white",
                 c("surface parcel:",paste("CAPE =", round(sbcape$cape,digits=1), "J/kg"), paste("CIN =", round(sbcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(sbcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(sbcape$plfc/100.,digits=0),"hPa"),
                 "","mean-layer parcel:",paste("CAPE =", round(mlcape$cape,digits=1), "J/kg"), paste("CIN =", round(mlcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mlcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mlcape$plfc/100.,digits=0),"hPa"),
                 "","most-unstable parcel:",paste("CAPE =", round(mucape$cape,digits=1), "J/kg"), paste("CIN =", round(mucape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mucape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mucape$plfc/100.,digits=0),"hPa"),
                 paste("source =",round(mucape$psource/100.,digits=0),"hPa"),
                 "", paste("PW = ",round(pw,digits=2),"mm")))
} else {
              legend("topright", inset=c(.15,0.0375), cex=0.75, lty=NULL, bg="white",
                 c("surface parcel:",paste("CAPE =", round(sbcape$cape,digits=1), "J/kg"), paste("CIN =", round(sbcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(sbcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(sbcape$plfc/100.,digits=0),"hPa"),
                 "","mean-layer parcel:",paste("CAPE =", round(mlcape$cape,digits=1), "J/kg"), paste("CIN =", round(mlcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mlcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mlcape$plfc/100.,digits=0),"hPa"),
                 "","most-unstable parcel:",paste("CAPE =", round(mucape$cape,digits=1), "J/kg"), paste("CIN =", round(mucape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mucape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mucape$plfc/100.,digits=0),"hPa"),
                 paste("source =",round(mucape$psource/100.,digits=0),"hPa"),
                 "", paste("PW = ",round(pw,digits=2),"mm"),
                 "",paste("0--6-km shear=",shear06,"kt"), paste("0--1-km shear=", shear01,"kt")))

## plot hodograph
     par(fig=c(0.04,0.38,0.675,0.985),new=TRUE)
## polar.plot exhibits some weird behavior, wherein the direction needs to be subtracted from 90 when plotting the lines, but added to 360 when plotting symbols.  I have no idea why
     suppressWarnings(polar.plot.rss(hodo$wspd[1:9],90.-hodo$dir[1:9],start=0,labels="",radial.lim=c(0,max(hodo$wspd)+5),line.col="red",lwd=3, rp.type="l", 
       show.radial.grid = FALSE, grid.bg="white",cex.lab=0.7))
     suppressWarnings(polar.plot.rss(hodo$wspd[1:9],360.+hodo$dir[1:9],labels="",radial.lim=c(0,max(hodo$wspd)+5),point.col="red", cex=0.3,point.symbols=19,lwd=2, rp.type="s", 
       show.radial.grid = FALSE, grid.bg="white",add=TRUE))
     suppressWarnings(radial.plot.labels(hodo$wspd[1:9],360.+hodo$dir[1:9]+10,labels=hodo$height[1:9]/1000.,radial.lim=c(0,max(hodo$wspd)+5),cex=0.7,units="polar",col="red"))
 }
}
