polar.plot.rss <-
function (lengths, polar.pos = NULL, labels, label.pos = NULL, 
    start = 0, clockwise = FALSE, rp.type = "r", cex.lab=1.0, ...) 
{
    npos <- length(lengths)
    if (is.null(polar.pos)) 
        radial.pos <- seq(0, (2 - 2/(npos + 1)) * pi, length = npos)
    else radial.pos <- pi * polar.pos/180
    if (start) 
        start <- pi * start/180
    if (is.null(label.pos)) 
        label.pos <- seq(0, 1.89 * pi, length = 18)
    else label.pos <- pi * label.pos/180
    if (missing(labels)) 
        labels <- as.character(seq(0, 340, by = 20))
    invisible(radial.plot.rss(lengths, radial.pos, labels, label.pos, 
        start = start, clockwise = clockwise, rp.type = rp.type, cex.lab=cex.lab, 
        ...))
}
