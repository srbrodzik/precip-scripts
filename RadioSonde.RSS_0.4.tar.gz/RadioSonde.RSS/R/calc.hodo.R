calc.hodo <-
function(data) {
## function to take an observed text sounding and calculate values that can be plotted on a hodograph
##   just requires a dataframe the same as what radiosonde requires, with speed and direction for winds
##  also requires altitude 

  d2r = pi/180. ## degree to radian conversion 

heights <- c(10,500,seq(1000,8000,by=1000)) ## get values at 0.1, 0.5, 1-8 km 
dir <- c()
wspd <- c()
uwind <- c()
vwind <- c()

 for (k in 1:length(heights)) {
  thislev <- which.min(abs(data$alt - heights[k]))
  dir <- rbind(dir,data$dir[thislev])
  wspd <- rbind(wspd,data$wspd[thislev])
  uwind <- rbind(uwind,-data$wspd[thislev]*cos((90-data$dir[thislev])*d2r))
  vwind <- rbind(vwind,-data$wspd[thislev]*sin((90-data$dir[thislev])*d2r))
 }

hodo <- data.frame(heights,dir,wspd,uwind,vwind)
return(hodo)
}
