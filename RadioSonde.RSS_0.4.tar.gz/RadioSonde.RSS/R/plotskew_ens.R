plotskew_ens <- function(skewarray, hodoarray=NULL, parcel=NULL, thermomem=1, hcol=NULL, title="",date="") {
## R function to plot a skew-T diagram, with the Bryan getcape code wrapped in.  Awesome!
## this version brings in an ensemble of skew-Ts and hodographs and plots them
##  inputs are two arrays:
##  1) array:  in the form required by the "RadioSonde" package, including
##  pressure, temperature, etc., with a third dimension being ensemble member 
##  2) hodo (optional): having height and wind speed/direction
## parcel is a specification of which parcel to plot, 
##  where 1=SB, 2=MU, and 3=ML, again with a third dimension being ensemble member
##   thermomem is which ensemble member to calculate and plot the thermodynamic variables for
##  hcol is an array of the colors we want to use for the different hodographs
##  title is the main title for the plot; date is date/time information like the initialization time, etc.
##   the one thing it won't correctly plot is the title and date/time information,
##  which should be added later by the main program
##  RSS 5/2/2013

## load in needed libraries/scripts
#library("RadioSonde")
#library("plotrix")
#source("~rschumac/R/thermo.R")

## set up skew-T
     mar.skewt <- c(4.1, 2.7, 2.1, 3.5)
     skewt.plt <- skewt.axis.rss(mar = mar.skewt)$plt
            windplot <- skewt.plt
            windplot[1] <- 0.8
            windplot[2] <- 0.95
     first.par <- par()
     skewt.axis.rss()

### plot temp/dewpoint
for (ee in 1:length(skewarray[1,1,])) {  ## loop over members 
  data <- as.data.frame(skewarray[,,ee])
    if (ee == 1){
     skewt.lines(data$temp, data$press, col = 2, lwd=2)
     skewt.lines(data$dewpt, data$press, col = 3, lwd=2)
## and virtual temp
     qv <- dewp_to_qv(data$press*100.,data$dewpt+273.15)
     data <- cbind(data, qv)
     tempv <- (data$temp+273.15)*(1.0+(461.5/287.04)*data$qv)/(1.0+data$qv)-273.15
     data <- cbind(data,tempv)
     skewt.lines(data$tempv,data$press, col="red", lwd=1,lty=2)  ## add the virtual temp of the sounding
    } else {
     skewt.lines(data$temp, data$press, col = 2, lwd=1)
     skewt.lines(data$dewpt, data$press, col = 3, lwd=1)
    }
  }
### plot winds
for (ee in 1:length(skewarray[1,1,])) {  ## loop over members 
  data <- as.data.frame(skewarray[,,ee])
  if(is.null(data$wspd) && is.null(data$dir)){  ## calculate dir/speed if needed
   wspd <- sqrt(data$uwind^2 + data$vwind^2)
   data <- cbind(data, wspd)
        
   dir <- 90.-atan2(-data$vwind, -data$uwind)*(180./pi)
   data <- cbind(data,dir)
  }
        par(new = TRUE, pty = "m", plt = windplot, err = -1)
        plotwind.rss(data, size = 1.4, legend = FALSE)
        par(plt = first.par$plt, mar = first.par$mar, new = FALSE,
            pty = first.par$pty, usr = first.par$usr)
        invisible()
    }
## add title and date
  title(title,cex.main=1.2)
  mtext(date,cex=1.1,padj=1)


# if(ee == 1) {
#  windplot <- plotsonde.rss(data, lwd=c(4,4,2), winds=T, col=c(2,3,1,1,1), s=2.2)
#  title(title,cex.main=1.5)
#  mtext(date,cex=1.4,padj=1)
#  first.par <- par()
#  } else {  ## just overplot the lines
#   skewt.lines(data$temp, data$press, lwd=4,col=2)
#   skewt.lines(data$dewp, data$press, lwd=4,col=3)
#    overplotsonde.rss(data,lwd=c(4,4,2),winds=T,windplot=windplot,
#       col=c(2,3,1,1,1), s=2.2)
#      par(new = TRUE, pty = "m", plt = windplot, err = -1)
#      overplotwind.rss(data, size = 2.2)
#      par(plt = first.par$plt, mar = first.par$mar, new = FALSE,
#      pty = first.par$pty, usr = first.par$usr)
#  }
 
## now run the wrapper for getcape to calculate CAPE!
## (for the member we asked for the thermo parcel for)
  ee <- thermomem 

  data <- as.data.frame(skewarray[,,ee])
   pw <- PWV(data, minp=100)
  ## first need q
   qv <- dewp_to_qv(data$press*100.,data$dewpt+273.15)
   data <- cbind(data, qv)

data <- data[complete.cases(data$temp),] # now cut down to just the complete temperature lines 
data$qv[is.na(data$qv)]<-0  ## set qv to zero where it's missing to avoid problems in getcape
## SBCAPE
sbcape <- getcape(1,data)
## MUCAPE
mucape <- getcape(2,data)
## MLCAPE
mlcape <- getcape(3,data)

## strip out the parcel temperature from this array
sbptv <- sbcape$ptv - 273.15
sbppres <- sbcape$ppres
sbcape <- sbcape[1,]
muptv <- mucape$ptv - 273.15
muppres <- mucape$ppres
mucape <- mucape[1,]
mlptv <- mlcape$ptv - 273.15
mlppres <- mlcape$ppres
mlcape <- mlcape[1,]

## and get and plot the parcel path for the desired parcel, if there is CAPE and the EL is defined
##  do the initial lifting of the dry parcel first
if (!parcel) { print("no parcel being drawn")   
} else if (parcel == 1){   ## SBCAPE
 if (sbcape$cape > 0 && sbcape$pel != 0){
  mtext("dashed black line shows ascent of surface parcel",side=1,padj=1,adj=-0.1, cex=0.8)
  skewt.lines(sbptv[sbppres<=sbcape$psource & sbppres>=sbcape$pel],
    sbppres[sbppres<=sbcape$psource & sbppres>=sbcape$pel]/100.,col="black",lwd=2.5,lty=2) 
 }
} else if (parcel == 2){  ## MUCAPE 
 if (mucape$cape > 0 && mucape$pel != 0){
  mtext("dashed black line shows ascent of parcel with max theta-e",side=1,padj=1,adj=-0.1, cex=0.8)
  skewt.lines(muptv[muppres<=mucape$psource & muppres>=mucape$pel],
    muppres[muppres<=mucape$psource & muppres>=mucape$pel]/100.,col="black",lwd=2.5,lty=2) 
 }
} else if (parcel == 3){  ## MLCAPE 
 if (mlcape$cape > 0 && mlcape$pel != 0){
  mtext("dashed black line shows mean 500-m layer parcel",side=1,padj=1,adj=-0.1, cex=0.8)
  skewt.lines(mlptv[mlppres<=mlcape$psource & mlppres>=mlcape$pel],
    mlppres[mlppres<=mlcape$psource & mlppres>=mlcape$pel]/100.,col="black",lwd=2.5,lty=2) 
 }
} 
  if(dimnames(skewarray)[[3]][thermomem]=="ensmean") {
   mtext("thermodynamic calcs are for ensemble mean profile",side=1,padj=2,adj=0, cex=0.8)
  } else {
  mtext(paste("thermodynamic calcs are for member",dimnames(skewarray)[[3]][thermomem]),side=1,padj=2,adj=0, cex=0.8)
  }

## and get hodograph for thermomem (this is for the shear calcs for this member) 
if(!is.null(hodoarray)) {

 hodo <- as.data.frame(hodoarray[,,ee])

## calculate shear quantities
    shear06u <- hodo$uwind[hodo$height==6000]-hodo$uwind[hodo$height==10]
    shear06v <- hodo$vwind[hodo$height==6000]-hodo$vwind[hodo$height==10]
    shear01u <- hodo$uwind[hodo$height==1000]-hodo$uwind[hodo$height==10] 
    shear01v <- hodo$vwind[hodo$height==1000]-hodo$vwind[hodo$height==10]
    shear06 <- round(sqrt(shear06u^2+shear06v^2),digits=1)
    shear01 <- round(sqrt(shear01u^2+shear01v^2),digits=1)
}

## make non-existent LFCs NA
    if(sbcape$plfc == 0 ) { sbcape$plfc <- NA }
    if(mucape$plfc == 0 ) { mucape$plfc <- NA }
    if(mlcape$plfc == 0 ) { mlcape$plfc <- NA }

## before plotting hodograph, add legend with the stability and shear info:
## add legend box
if(is.null(hodoarray)){  ## omit shear variables if no hodo
              legend("topright", inset=c(.15,0.0375), cex=0.75, lty=NULL, bg="white",
                 c("surface parcel:",paste("CAPE =", round(sbcape$cape,digits=1), "J/kg"), paste("CIN =", round(sbcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(sbcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(sbcape$plfc/100.,digits=0),"hPa"),
                 "","mean-layer parcel:",paste("CAPE =", round(mlcape$cape,digits=1), "J/kg"), paste("CIN =", round(mlcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mlcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mlcape$plfc/100.,digits=0),"hPa"),
                 "","most-unstable parcel:",paste("CAPE =", round(mucape$cape,digits=1), "J/kg"), paste("CIN =", round(mucape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mucape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mucape$plfc/100.,digits=0),"hPa"),
                 paste("source =",round(mucape$psource/100.,digits=0),"hPa"),
                 "", paste("PW = ",round(pw,digits=2),"mm")))
} else {
              legend("topright", inset=c(.15,0.0375), cex=0.75, lty=NULL, bg="white",
                 c("surface parcel:",paste("CAPE =", round(sbcape$cape,digits=1), "J/kg"), paste("CIN =", round(sbcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(sbcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(sbcape$plfc/100.,digits=0),"hPa"),
                 "","mean-layer parcel:",paste("CAPE =", round(mlcape$cape,digits=1), "J/kg"), paste("CIN =", round(mlcape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mlcape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mlcape$plfc/100.,digits=0),"hPa"),
                 "","most-unstable parcel:",paste("CAPE =", round(mucape$cape,digits=1), "J/kg"), paste("CIN =", round(mucape$cin,digits=1),"J/kg"),
                 paste("LCL =",round(mucape$plcl/100.,digits=0),"hPa"), paste("LFC =",round(mucape$plfc/100.,digits=0),"hPa"),
                 paste("source =",round(mucape$psource/100.,digits=0),"hPa"),
                 "", paste("PW = ",round(pw,digits=2),"mm"),
                 "",paste("0--6-km shear=",shear06,"kt"), paste("0--1-km shear=", shear01,"kt")))
} ## end of hodoarray check

### plot hodograph
for (ee in 1:length(skewarray[1,1,])) {  ## loop over members again 
if(!is.null(hodoarray)){
## plot hodograph
   hodo <- as.data.frame(hodoarray[,,ee])
 if(is.null(hodo$wspd) && is.null(hodo$dir)){
    wspd <- sqrt(hodo$uwind^2 + hodo$vwind^2)
    hodo <- cbind(hodo, wspd)

    dir <- 180.+atan2(-hodo$vwind, -hodo$uwind)*(180./pi)
    hodo <- cbind(hodo,dir)
  }
    if(ee == 1){  ## first time through
     par(fig=c(0.03,0.42,0.65,0.985),new=TRUE)
## polar.plot exhibits some weird behavior, wherein the direction needs to be subtracted from 90 when plotting the lines, but added to 360 when plotting symbols.  I have no idea why
     polar.plot.rss(hodo$wspd[1:9],90.-hodo$dir[1:9],start=0,labels="",radial.lim=c(0,max(hodo$wspd)+5),line.col=hcol[ee],lwd=3, rp.type="l", 
       show.radial.grid = FALSE, grid.bg="white")
} else { ## other times through
     polar.plot.rss(hodo$wspd[1:9],90.-hodo$dir[1:9],start=0,labels="",radial.lim=c(0,max(hodo$wspd)+5),line.col=hcol[ee],lwd=3, rp.type="l", 
       show.radial.grid = FALSE, grid.bg="white",add=TRUE)
}
     polar.plot.rss(hodo$wspd[1:9],360.+hodo$dir[1:9],labels="",radial.lim=c(0,max(hodo$wspd)+5),point.col=hcol[ee], cex=0.7,point.symbols=19,lwd=3, rp.type="s", 
       show.radial.grid = FALSE, grid.bg="white",add=TRUE)
     radial.plot.labels(hodo$wspd[1:9],360.+hodo$dir[1:9]+10,labels=hodo$height[1:9]/1000.,radial.lim=c(0,max(hodo$wspd)+5),units="polar",col=hcol[ee])
}
}  ## end of loop over members
}  ## end of function
